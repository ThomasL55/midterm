import os
import logging
from flask import Flask, render_template, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///game.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

@app.route('/')
def index():
    # Initialize default settings if not present
    if 'difficulty' not in session:
        session['difficulty'] = 'easy'
        session['use_keyboard'] = False
        session['high_contrast'] = False
        session['sound_enabled'] = True
        session['game_speed'] = 1000  # Default speed in milliseconds
    return render_template('game.html', settings=session)

@app.route('/documentation')
def documentation():
    return render_template('documentation.html')

@app.route('/settings')
def settings():
    return render_template('settings.html', settings=session)

@app.route('/save_settings', methods=['POST'])
def save_settings():
    settings = request.get_json()
    session['difficulty'] = settings.get('difficulty', 'medium')
    session['use_keyboard'] = settings.get('use_keyboard', False)
    session['high_contrast'] = settings.get('high_contrast', False)
    session['sound_enabled'] = settings.get('sound_enabled', True)
    session['game_speed'] = settings.get('game_speed', 1000)
    return jsonify({'status': 'success'})

with app.app_context():
    import models
    db.create_all()