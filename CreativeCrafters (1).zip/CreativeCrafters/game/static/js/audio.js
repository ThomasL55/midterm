class GameAudio {
    constructor() {
        this.synth = new Tone.Synth().toDestination();
        this.notes = ['C4', 'E4', 'G4', 'B4'];
    }

    async playSuccess() {
        await Tone.start();
        this.synth.triggerAttackRelease('C4', '8n');
        setTimeout(() => this.synth.triggerAttackRelease('E4', '8n'), 100);
        setTimeout(() => this.synth.triggerAttackRelease('G4', '8n'), 200);
    }

    async playError() {
        await Tone.start();
        this.synth.triggerAttackRelease('A3', '8n');
        setTimeout(() => this.synth.triggerAttackRelease('G3', '8n'), 200);
    }

    async playTile(index) {
        await Tone.start();
        this.synth.triggerAttackRelease(this.notes[index % this.notes.length], '8n');
    }
}

const gameAudio = new GameAudio();
