from app import db

# Game related models can be added here if needed
# For now, we're using session-based storage for game state
